
- Compile the code using `make`. It will generate two executables:
  `a32.out` (32-bit code) and `a64.out` (64-bit code).

- Run the two Python programs to generate the shellcode, one for 32-bit,
  and the other for 64-bit. You can modify the shellcode.  

- Run `a32.out` and `a64.out` to test your shellcode.
